﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System.Threading.Tasks;

namespace UniSozluk.Areas.Admin.Identity
{
    public static class SeedIdentity
    {
        //public static async Task<IApplicationBuilder> PrepareDatabase(this IApplicationBuilder app)
        //{
        //    using var scopedService = app.ApplicationServices.CreateAsyncScope
        //}
    }
}
