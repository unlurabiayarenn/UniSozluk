﻿namespace UniSozluk.Models
{
    public class UserComment
    {
        public int Id { get; set; }
        public string nickname { get; set; }
    }
}
