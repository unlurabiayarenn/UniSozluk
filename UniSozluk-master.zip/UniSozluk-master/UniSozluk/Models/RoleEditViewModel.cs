﻿namespace UniSozluk.Models
{
    public class RoleEditViewModel
    {
        public int Id { get; set; }
        public string name { get; set; }
    }
}
